# FIKRY DAILY
Offline Arabic daily planner: tasks, worship checklist, habits, daily summary.
Data is stored locally using SharedPreferences. No internet permission or external dependencies.
Build with JDK 17, Gradle 8.9, Android SDK 35 and Android Gradle Plugin 8.7.3.

package com.fikry.daily;
import android.app.*; import android.os.*; import android.graphics.Color; import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable; import android.view.*; import android.widget.*;
import android.content.SharedPreferences; import org.json.*; import java.text.*; import java.util.*;
public class MainActivity extends Activity {
 int bg=0xFF101326,panel=0xFF202744,purple=0xFF9067FF,white=0xFFF5F5FF;
 SharedPreferences sp; LinearLayout root,body; String page="tasks";
 public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("daily",0);shell();show();}
 GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
 TextView txt(String s,int z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(white);t.setPadding(5,7,5,7);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(-1);b.setAllCaps(false);b.setBackground(shape(purple,18));return b;}
 void shell(){
  root=col();root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackgroundColor(bg);setContentView(root);
  LinearLayout head=col();head.setPadding(18,22,18,14);head.addView(txt("فِكري | يومي",25,true));
  head.addView(txt(new SimpleDateFormat("EEEE، d MMMM yyyy",new Locale("ar")).format(new Date()),13,false));root.addView(head);
  LinearLayout nav=row();nav.setPadding(6,5,6,8);
  String[][] tabs={{"المهام","tasks"},{"العبادات","worship"},{"العادات","habits"},{"ملخص اليوم","summary"}};
  for(String[] a:tabs){Button b=btn(a[0]);b.setTextSize(11);b.setBackground(shape(page.equals(a[1])?purple:panel,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,48,1);p.setMargins(3,0,3,0);nav.addView(b,p);b.setOnClickListener(v->{page=a[1];shell();show();});}root.addView(nav);
  ScrollView sc=new ScrollView(this);body=col();body.setPadding(15,10,15,25);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
 }
 JSONArray arr(String k){try{return new JSONArray(sp.getString(k,"[]"));}catch(Exception e){return new JSONArray();}}
 void save(String k,JSONArray a){sp.edit().putString(k,a.toString()).apply();}
 void card(String h,String sub){LinearLayout c=col();c.setPadding(14,12,14,12);c.setBackground(shape(panel,18));c.addView(txt(h,18,true));c.addView(txt(sub,12,false));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,12);body.addView(c,p);}
 void add(String key){EditText e=new EditText(this);e.setSingleLine(true);e.setHint("اكتب هنا...");e.setTextColor(white);e.setHintTextColor(0xFFAAAAAA);e.setBackground(shape(panel,14));new AlertDialog.Builder(this).setTitle("إضافة عنصر").setView(e).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{String s=e.getText().toString().trim();if(!s.isEmpty()){JSONArray a=arr(key);JSONObject o=new JSONObject();try{o.put("title",s);o.put("done",false);a.put(o);}catch(Exception x){}save(key,a);show();}}).show();}
 void entries(String key,String empty){
  JSONArray a=arr(key);if(a.length()==0)body.addView(txt(empty,14,false));
  for(int i=0;i<a.length();i++){final int n=i;JSONObject o=a.optJSONObject(i);if(o==null)continue;
   LinearLayout r=row();r.setPadding(8,5,8,5);r.setBackground(shape(panel,14));CheckBox cb=new CheckBox(this);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(purple));cb.setChecked(o.optBoolean("done"));r.addView(cb);
   TextView name=txt(o.optString("title"),14,false);r.addView(name,new LinearLayout.LayoutParams(0,-2,1));
   Button del=btn("حذف");del.setTextSize(10);del.setBackground(shape(0xFF783C58,12));r.addView(del);
   LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,3,0,3);body.addView(r,p);
   cb.setOnCheckedChangeListener((v,checked)->{JSONArray x=arr(key);JSONObject q=x.optJSONObject(n);if(q!=null){try{q.put("done",checked);}catch(Exception ignored){}save(key,x);}});
   del.setOnClickListener(v->{JSONArray x=arr(key),y=new JSONArray();for(int j=0;j<x.length();j++)if(j!=n)y.put(x.opt(j));save(key,y);show();});
  }
  Button b=btn("+ إضافة");body.addView(b);b.setOnClickListener(v->add(key));
 }
 void show(){body.removeAllViews();
  if(page.equals("tasks")){card("مهامي اليوم","أضف مهامك وحدد ما أنجزته");entries("tasks","لا توجد مهام. ابدأ بإضافة أول مهمة.");}
  else if(page.equals("worship")){card("متابعة العبادات","قائمة شخصية للتذكير والمتابعة");entries("worship","أضف العبادات والأذكار التي تريد متابعتها.");Button d=btn("إضافة قائمة مقترحة");body.addView(d);d.setOnClickListener(v->{JSONArray a=arr("worship");String[] ss={"صلاة الفجر","صلاة الظهر","صلاة العصر","صلاة المغرب","صلاة العشاء","أذكار الصباح","أذكار المساء","قراءة القرآن"};for(String s:ss){JSONObject o=new JSONObject();try{o.put("title",s);o.put("done",false);a.put(o);}catch(Exception ignored){}}save("worship",a);show();});}
  else if(page.equals("habits")){card("عاداتي وأهدافي","تابع العادات الصغيرة يومًا بعد يوم");entries("habits","لم تضف عادات بعد.");}
  else {card("ملخص اليوم","إنجازاتك محفوظة على جهازك");for(String[] x:new String[][]{{"المهام","tasks"},{"العبادات","worship"},{"العادات","habits"}}){JSONArray a=arr(x[1]);int n=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optBoolean("done"))n++;}card(x[0],"أنجزت "+n+" من "+a.length());}body.addView(txt("نصيحة اليوم: ابدأ بخطوة صغيرة واستمر.",16,true));}
 }
}
